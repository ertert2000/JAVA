package com.proghelp;

public class EmptyFieldException extends Exception{
    public EmptyFieldException(String message) {
        super(message);
    }
}
